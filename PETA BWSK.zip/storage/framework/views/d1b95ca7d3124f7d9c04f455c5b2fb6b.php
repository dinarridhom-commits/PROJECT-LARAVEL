 <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <div class="sidebar-brand d-flex align-items-center justify-content-between px-3">
                <a class="d-flex align-items-center text-white text-decoration-none flex-grow-1" href="/home">
                    <div class="sidebar-brand-icon">
                        <i class="fas fa-home"></i>
                    </div>
                    <div class="sidebar-brand-text mx-2">TOKO KAMI</div>
                </a>
                <button class="btn btn-sm btn-link text-white d-md-none p-1" id="sidebarMobileClose" type="button" title="Tutup Menu" style="opacity: 0.85;">
                    <i class="fas fa-times fa-lg"></i>
                </button>
            </div>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item <?php echo e(request()->is('home') || request()->is('/') || request()->is('dashboard') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Menu Utama
            </div>

            <!-- Nav Item - Tables -->
            <li class="nav-item <?php echo e(request()->is('produk*') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('produk.index')); ?>">
                    <i class="fas fa-fw fa-boxes"></i>
                    <span>Produk</span></a>
            </li>
            <li class="nav-item <?php echo e(request()->is('kategori*') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('kategori.index')); ?>">
                    <i class="fas fa-fw fa-tags"></i>
                    <span>Kategori</span></a>
            </li>
            <li class="nav-item <?php echo e(request()->is('peta') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('peta')); ?>">
                    <i class="fas fa-fw fa-map-marked-alt"></i>
                    <span>Peta Lokasi</span></a>
            </li>

            <?php if(Auth::check() && Auth::user()->role === 'superadmin'): ?>
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Super Admin
            </div>

            <li class="nav-item <?php echo e(request()->is('users*') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                    <i class="fas fa-fw fa-users-cog"></i>
                    <span>Manajemen User</span></a>
            </li>
            <?php elseif(Auth::check() && Auth::user()->role === 'admin'): ?>
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Admin Panel
            </div>

            <li class="nav-item <?php echo e(request()->is('users*') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                    <i class="fas fa-fw fa-users"></i>
                    <span>Daftar Pengguna</span></a>
            </li>
            <?php endif; ?>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar --><?php /**PATH C:\Users\user\BELAJAR-LARAVEL\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>