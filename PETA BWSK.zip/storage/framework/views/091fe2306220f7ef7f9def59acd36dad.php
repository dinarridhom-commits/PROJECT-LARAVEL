<!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer --><?php /**PATH C:\Users\user\BELAJAR-LARAVEL\resources\views/layout/footer.blade.php ENDPATH**/ ?>